import { Component } from '@angular/core';
import { Student } from './model/student';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public title = 'I Love India';
  public flag:boolean = false;
  public names:string[] = ["Name1","Name2","Name3","Name4","Name5"];

  public students:Student[]  = [
    {id:1,name:"superstar"},
    {id:2,name:"Bashabhai"},
    {id:3,name:"Kalaiyaan"}
  ]

  doHandleAddStudent(data:any) {
    console.log(data);
    this.students.push(data);
  }  

  onTitleChange(e:any){
    console.log(e.target.value);
    let val = e.target.value;
    this.title = val;
  }
  
  doHandleToggle() {
    this.flag = !this.flag;
  }

  doReadData(val:string){
    alert(val);
  }
}
