import { ThrowStmt } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private route:Router,private dataService:DataService) { 
    this.dataService.isAuthticated= false;
  }

  ngOnInit(): void {
  }

  doNavigateToDashBoard(){
    this.dataService.isAuthticated= true;
    this.route.navigate(['dashboard']);
  }

}
