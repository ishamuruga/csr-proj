export class Student {
    public id:number=0;
    public name:string="";

    constructor(_id:number,_name:string){
        this.id = _id;
        this.name = _name;
    }
}
